<?php

/**
 * Fired during plugin activation
 *
 * @link       https://devexhub.com
 * @since      1.0.0
 *
 * @package    Devbot
 * @subpackage Devbot/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Devbot
 * @subpackage Devbot/includes
 * @author     Devexhub Team <karan@devexhub.in>
 */
class Devbot_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
