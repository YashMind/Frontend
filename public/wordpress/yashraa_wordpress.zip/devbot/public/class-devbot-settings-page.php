<?php

if (!defined("ABSPATH")) {
    exit(); // Exit if accessed directly
}

add_action("admin_menu", "devbots_embed_menu");

function devbots_embed_menu()
{
    add_options_page(
        "DevBots Settings",
        "DevBots",
        "manage_options",
        "devbots",
        "devbots_settings_page"
    );
}

function devbots_settings_page()
{
    ?>
    <div class="wrap">
        <h2>DevBots</h2>
        <h3>Instructions</h3>

        <ol>
            <li>Go to <b>Embed / Share</b> page of your bot</li>
            <li>Under <b>Using Embed Script</b> section you would see the embed script like so: <code> &lt;script defer src="https://yashraa.ai/embed.js" data-bot-id="YOUR_BOT_ID"&gt;&lt;script&gt; </code> </li>
            <li>Copy <code>https://yashraa.ai/embed.js</code> or your custom domain URL and paste it in <b>Source URL</b> input field</li>
            <li>Copy <code>YOUR_BOT_ID (which might be someting like this: clvnszmoj00012e2flzihll25)</code> and paste it in <b>Bot ID</b> input field</li>
            <li>Click on Save Changes</li>
        </ol>
        <form method="post" action="options.php">
            <?php settings_fields("devbots-settings-group"); ?>
            <?php do_settings_sections("devbots-settings-group"); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Source URL</th>
                    <td><input type="text" id="devbots_chatbot_embed_code" name="devbots_chatbot_embed_code" value="<?php echo esc_attr(get_option("devbots_chatbot_embed_code")); ?>"></td>
                </tr>
                <tr valign="top">
                    <th scope="row">DevBots Embed ID</th>
                    <td><input type="text" id="devbots_chatbot_embed_code_two" name="devbots_chatbot_embed_code_two" value="<?php echo esc_attr(get_option("devbots_chatbot_embed_code_two")); ?>"></td>
                </tr>
            </table>

            <?php submit_button(); ?>

        </form>
    </div>
<?php
}

add_action("admin_init", "devbots_settings");

function devbots_settings()
{
    register_setting("devbots-settings-group", "devbots_chatbot_embed_code");
    register_setting(
        "devbots-settings-group",
        "devbots_chatbot_embed_code_two"
    );
}
