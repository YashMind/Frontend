<?php
/*
 * Plugin Name:       Devbots
 * Plugin URI:        https://wordpress.org/plugins/devbots/
 * Description: Easily add your Devbots AI chatbot to your WordPress site.
 * Version:           1.0.12
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Devbots
 * Author URI:        https://devbots.ai
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       devbots
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

define( 'FASTBOTS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

require_once(FASTBOTS_PLUGIN_DIR . 'class-devbot-settings-page.php');

function devbots_chatbot_to_header() {
    $embed_code = get_option('devbots_chatbot_embed_code');
	$embed_code_two = get_option('devbots_chatbot_embed_code_two');
    if (!empty($embed_code)&&!empty($embed_code_two)) {
		$full_embed_code = "<script>
		var scriptElement = document.createElement('script');
	  
		scriptElement.src = '".$embed_code."';
		scriptElement.setAttribute('data-bot-id', '".$embed_code_two."');
		scriptElement.defer = true;
	  
		document.head.appendChild(scriptElement);
	  </script>";
        echo wp_kses(
		    $full_embed_code,
		    array(
		        'script'      => array(
		            'src'  => array(),
		            'data-bot-id' => array(),
		            'defer'  => array(),
		        ),
		    )
		);
    }
}

add_action('wp_head', 'devbots_chatbot_to_header');
