<?php
/*
 * Plugin Name:       Yashraa.Ai
 * Plugin URI:        https://yashraa.ai/
 * Description: Easily add your Devbots AI chatbot to your WordPress site.
 * Version:           1.0.12
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Devbots
 * Author URI:        https://yashraa.ai/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       devbots
 * Domain Path:       /languages
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

define('DEVBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));

require_once(DEVBOT_PLUGIN_DIR . 'class-devbot-settings-page.php');

function devbots_chatbot_to_footer()
{
	$embed_code = get_option('devbots_chatbot_embed_code');
	$embed_code_two = get_option('devbots_chatbot_embed_code_two');
	if (!empty($embed_code) && !empty($embed_code_two)) {
		// Sanitize the inputs
		$embed_code = esc_url($embed_code);
		$embed_code_two = esc_attr($embed_code_two);

		// Output the script tag directly (the standard embed method)
		echo '<script defer src="' . $embed_code . '" data-bot-id="' . $embed_code_two . '"></script>';
	}
}

add_action('wp_footer', 'devbots_chatbot_to_footer');
